# LaughChain ($LCH)

LaughChain is a memecoin on Solana built for joy, memes, and community. This is the official archive of the project including whitepapers, philosophy, and proof of ownership.

© 2025 LaughChain. All rights reserved.